
#include <emXGUI.h>
#include "JPEG_picture.h"
#include "JPEG_decode_dma.h"


#if 0
#define path1 "0:/humiture_desktop.jpg"
void Show_Picture()
{
//        JPEG_OUTPUT_DATA_BUFFER = mymalloc(SRAMEX,1024*600*2);
        SURFACE *pSurf;
	
				HDC hdc_mem;
				
				HDC hdc;
				
				hdc = BeginPaint(hwnd,&ps);
	
        JPEG_Handle.Instance = JPEG;
	
        HAL_JPEG_Init(&JPEG_Handle);
       
//        HAL_JPEG_DeInit(&JPEG_Handle);       
//       
//        myfree(SRAMEX,JPEG_OUTPUT_DATA_BUFFER);
      
				JPEG_picture(path1,LCD_FRAME_BUFFER);

				pSurf =CreateSurface(SURF_RGB565,JPEG_Info.ImageWidth,JPEG_Info.ImageHeight, 0, (U16*)LCD_FRAME_BUFFER);     

				hdc_mem =CreateDC(pSurf,NULL);

				BitBlt(hdc,0, 0, JPEG_Info.ImageWidth, JPEG_Info.ImageHeight, hdc_mem, 0 , 0, SRCCOPY);     
				 
				DeleteSurface(pSurf);
	
				DeleteDC(hdc_mem);
				
				EndPaint(hwnd,&ps);
}
#endif
