/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __JPEG_DECODE_DMA_H
#define __JPEG_DECODE_DMA_H

/* Includes ------------------------------------------------------------------*/
#include "stm32H7xx.h"

extern JPEG_HandleTypeDef    JPEG_Handle;
extern JPEG_ConfTypeDef      JPEG_Info;

extern __IO uint8_t Jpeg_HWDecodingEnd;

#endif /* __DECODE_DMA_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
