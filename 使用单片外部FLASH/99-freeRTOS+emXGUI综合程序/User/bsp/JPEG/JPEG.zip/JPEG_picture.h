#ifndef __JPEG_PICTURE_H
#define __JPEG_PICTURE_H

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "..\JPEG\JPEG_decode_dma.h"

extern uint8_t *JPEG_TempBuff;
extern uint8_t PIC_JPEG_FLAG;

extern void JPEG_Decode_Mem(void);
extern void JPEG_Decode_free(void);
extern void JPEG_picture(char *path,uint32_t *databuf);
extern void PIC_JPEG_GetDataCallback(JPEG_HandleTypeDef *hjpeg, uint32_t NbDecodedData);
extern void PIC_JPEG_DataReadyCallback (JPEG_HandleTypeDef *hjpeg, uint8_t *pDataOut, uint32_t OutDataLength);

//extern void Start_JEPG(char *path,uint32_t *databuf);

#endif /* __DECODE_DMA_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
