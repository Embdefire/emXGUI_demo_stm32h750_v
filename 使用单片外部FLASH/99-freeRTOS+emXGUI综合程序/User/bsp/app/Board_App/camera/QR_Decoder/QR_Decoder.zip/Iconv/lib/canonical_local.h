  (int)(long)&((struct stringpool_t *)0)->stringpool_str169,
  (int)(long)&((struct stringpool_t *)0)->stringpool_str267,
